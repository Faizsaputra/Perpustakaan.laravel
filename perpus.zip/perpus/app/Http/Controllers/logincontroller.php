<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class logincontroller extends Controller
{
    public Function index(){
        return view("login.index");
    }
    public Function authenticate(Request $request){
       $validete = $request->validate([
            'email'=>'required',
            'password'=>'required',
            
        ]);
       if (Auth::attempt($validete)){
        $request->session()->regenerate();
        return redirect()->intended(route('buku'));
       }
       else {
        return redirect()->back()->withInput()->withError(['error','gagal login']);
       }
    }
}
