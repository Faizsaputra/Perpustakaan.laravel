<!--awal KONTEN-->
<div class="col-md-9">
     <?php echo $__env->yieldContent('isihalaman'); ?>                 
</div>
<!--akhir KONTEN-->
</div>
</div><?php /**PATH C:\xampp\perpus\resources\views/konten.blade.php ENDPATH**/ ?>