<p>
    <div class="col-md-12">
        <div class="row" style="background:#ccc">
            <!--awal SIDEBAR-->
            <div class="col-md-3">
                <img src="<?php echo e(asset('gambar')); ?>/sidebar.jpg" width="100%" height="100%">
            </div>
            <!--akhir SIDEBAR--><?php /**PATH C:\praktikum framework\perpus\resources\views/sidebar.blade.php ENDPATH**/ ?>