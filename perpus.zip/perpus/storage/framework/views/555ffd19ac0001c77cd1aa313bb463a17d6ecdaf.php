<!--awal KONTEN-->
<div class="col-md-9">
     <?php echo $__env->yieldContent('isihalaman'); ?>                 
</div>
<!--akhir KONTEN-->
</div>
</div><?php /**PATH D:\Semester 3 IT\Pemrograman web praktek S3\perpus\resources\views/konten.blade.php ENDPATH**/ ?>